//Banker's Algorithm

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, const char* argv[]){
  int row = 0;
  int col = 0;
  int count = 0;
  int numOfProcess;
  int r = 0;

  printf("\n Enter the number of processes: ");
  scanf("%d", &numOfProcess);

  int resources;

  printf("\n Enter the number of resources: ");
  scanf("%d", &resources);

  int *available = (int *) malloc(sizeof(int) * resources);
  int **maximum = (int **) malloc(sizeof(int) * numOfProcess);

  for(r = 0; r < numOfProcess; r++){
      maximum[r] = (int *) malloc(sizeof(int) * resources);
  }

  int **allocation = (int **) malloc(sizeof(int) * numOfProcess);

  for(r = 0; r < numOfProcess; r++){
    allocation[r] = (int *) malloc(sizeof(int) * resources);
  }

  int **need = (int **) malloc(sizeof(int) * numOfProcess);

  for(r = 0; r < numOfProcess; r++){
    need[r] = (int *) malloc(sizeof(int) * resources);
  }

  int processSequence[numOfProcess];

  for(row = 0; row < resources; row++){
      printf("\n Available resources %d: ", (row + 1));
      scanf("%d", &available[row]);
    }

  for(row = 0; row < numOfProcess; row++){
      for(col = 0; col < resources; col++){
        printf("\n Allocation P %d for R %d: ", (row + 1), (col + 1));
        scanf("%d", &allocation[row][col]);
      }
  }

  for(row = 0; row < numOfProcess; row++){
    for(col = 0; col < resources; col++){
      printf("\n MAX P %d for R %d: ", (row + 1), (col + 1));
      scanf("%d", &maximum[row][col]);
      need[row][col] = maximum[row][col] - allocation[row][col];
    }
  }

  printf("\n Available Resources: ");

  for(row = 0; row < resources; row++){
      printf("%4d", available[row]);
  }

  printf("\n Allocation \t MAX \t\t\t Need\n");

  for(row = 0; row < numOfProcess; row++){
      printf("P%d",(row + 1));
      for(col = 0; col < resources; col++)
      printf("%4d", allocation[row][col]);
      printf("\t\t");

      for(col = 0; col < resources; col++)
      printf("%4d", maximum[row][col]);
      printf("\t\t");

      for(col = 0; col < resources; col++)
      printf("%4d", need[row][col]);
      printf("\n");
    }

    int *work = (int *) malloc(sizeof(int) * resources);

    for(row = 0; row < resources; row++){
        work[row] = available[row];
    }

    int *finish = (int *) malloc(sizeof(int) * numOfProcess);

    for(row = 0; row < numOfProcess; row++){
        finish[row] = 0;
    }

    int checking = 1;

    while(checking){
        checking = 0;
        for(row = 0; row < numOfProcess; row++){
          if(!finish[row]){
            int col;
            for(col = 0; col < resources; col++)
              if(need[row][col] > work[col])
              break;
              if(col == resources){
                for(col = 0; col < resources; col++)
                work[col] = work[col] + allocation[row][col];
                finish[row] = 1;
                checking = 1;
                processSequence[count++] = row;
              }

          }

        }

    }
  int counter;
  for(counter = 0; counter < numOfProcess; counter++){
    if(!finish[counter])
  }

  break;
  printf("\n Safe state and sequence is \n");

  if(counter == numOfProcess){
    for(r = 0; r < count; r++){
      printf(" Process: %d\n", processSequence[r]);
    }
  }

  else{
    printf("\n Deadlock occurs");
  }

}
